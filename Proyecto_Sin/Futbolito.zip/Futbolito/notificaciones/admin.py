from django.contrib import admin
from notificaciones.models import Notificacion

# Register your models here.

#@admin.register(Notificacion)
#class NotificacionAdmin(admin.ModelAdmin):
#    pass